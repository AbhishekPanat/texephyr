<?php 

global $con;

function rand_num($digit=0){
    $str=str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890");
    return $str = substr($str,0,$digit);
}

function pr($arr)
{
	echo "<pre>";
	print_r($arr);
}
function prx($arr)
{
	echo "<pre>";
	print_r($arr);
	die;
}

function safe($string)
{
	global $con;
    $string = mysqli_real_escape_string($con,$string);
    return $string;
}

function redirect($link)
{
  ?>
  <script>
    window.location.href='<?php echo $link ?>';
  </script>
  <?php
  die();
}
function alertredirect($msg,$link)
{
	?>
	<script>
		alert('<?php echo $msg ?>');
		window.location.href='<?php echo $link ?>';
	</script>
	<?php
	die();
}

function get_event_list($department='')
{
    global $con;
    $sqls = "SELECT * FROM event ";
    if($department!='')
    {
        $sqls .="WHERE department = '$department' ";
    }
	$res=mysqli_query($con,$sqls);
	$datas=array();
	if(mysqli_num_rows($res)>0)
	{
	    while($row = mysqli_fetch_assoc($res))
	    {
	        $datas[]=$row;    
	    }
	}
	return $datas;
}

function vehicle_fuel($catid='',$field='')
{
    global $con;
    $sqls = "SELECT * FROM tbl_master_vehicle_fuel ";
    if($catid!='')
    {
        $sqls .="WHERE id ='$catid'";
    }
	$res=mysqli_query($con,$sqls);
	$datas="";
	if(mysqli_num_rows($res)>0)
	{
	    while($row = mysqli_fetch_assoc($res))
	    {
	        $datas=$row[$field];    
	    }
	}
	return $datas;
}



?>