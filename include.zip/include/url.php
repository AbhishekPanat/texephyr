<?php 
define('SERVER_PATH','http://localhost/texephyr22-website/');
define('MAIN_SERVER_PATH',$_SERVER['DOCUMENT_ROOT'].'/');

//image upload folder url
define('IMAGE_PATHs',SERVER_PATH.'image/');

define('IMAGE_PATH',SERVER_PATH.'image/idcard/');
define('IMAGE_PATH_FOLDER',$_SERVER['DOCUMENT_ROOT'].'/texephyr22-website/image/idcard/');


//image upload folder url
define('INDEX_PATH','http://localhost/texephyr22-website/index.php');

?>